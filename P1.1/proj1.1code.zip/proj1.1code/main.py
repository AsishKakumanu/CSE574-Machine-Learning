
# coding: utf-8

# In[106]:


import sys
print(sys.executable)


# ## Logic Based FizzBuzz Function [Software 1.0]

# In[107]:


import pandas as pd

def fizzbuzz(n):
    
    # Logic Explanation
    if n % 3 == 0 and n % 5 == 0:
        return 'fizzbuzz'
    elif n % 3 == 0:
        return 'fizz'
    elif n % 5 == 0:
        return 'buzz'
    else:
        return 'other'


# ## Create Training and Testing Datasets in CSV Format

# In[108]:


def createInputCSV(start,end,filename):
    
    # Why list in Python?
    
    '''List is ordered and mutable, Allows duplicates, Lists can be used as stack and queues.
    In this program, Data and Labels are added into the list. 
    So that they can be used as a dataset for training and testing.'''
    
    inputData   = []
    outputData  = []
    
    # Why do we need training Data?
    
    '''Training Data is nothing but enriched or labeled data you need to train your models. 
    You might just need to collect more of it to sharpen your model accuracy. 
    Machines learns when they see enough relevant data. 
    Using the knowledge it possess by processing the relevant data, you can model algorithms to find relationships, detect patterns, understand complex problems and make decisions. 
    Eventually, the quality, variety, and quantity of your training data determines the success of your machine learning models.
'''
    for i in range(start,end):
        inputData.append(i)
        outputData.append(fizzbuzz(i))
    
    # Why Dataframe?
    
    '''Dataframe is a primary datatype in pandas Data analysis library. 
    Dataframe is an extension of Multidimensional Matrix. 
    Every column in the matrix has to be the same data type. 
    Whereas a dataframe can have different data types of data in each column. 
    In this instance, we are passing data and labels which are two different data types. '''
    
    dataset = {}
    dataset["input"]  = inputData
    dataset["label"] = outputData
    
    # Writing to csv
    pd.DataFrame(dataset).to_csv(filename)
    
    print(filename, "Created!")


# ## Processing Input and Label Data

# In[109]:


def processData(dataset):
    
    # Why do we have to process?
    
    '''As dataset is of a datatype "dictionary". 
    We process the data and get values and put them in data & label lists.'''
    
    data   = dataset['input'].values
    labels = dataset['label'].values
    
    processedData  = encodeData(data)
    processedLabel = encodeLabel(labels)
    
    return processedData, processedLabel


# In[110]:


def encodeData(data):
    
    processedData = []
    
    for dataInstance in data:
        
        # Why do we have number 10?
        
        '''It's Cheating if we use 1 to 100 as our training data. 
        So our training dataset would be 101 to 1001. 
        As we are doing bitwise right shift operation. 
        x>>y Bitwise is also represented as x by 2**y.  
        So if the num of digits is 10, then the maximum number will be 1024, which is greater than 1000. 
        Now, each input i.e DataInstance  is turned into a binary vector. 
'''
        processedData.append([dataInstance >> d & 1 for d in range(10)])
    
    return np.array(processedData)


# In[111]:


from keras.utils import np_utils

def encodeLabel(labels):
    
    processedLabel = []
    
    for labelInstance in labels:
        if(labelInstance == "fizzbuzz"):
            # Fizzbuzz
            processedLabel.append([3])
        elif(labelInstance == "fizz"):
            # Fizz
            processedLabel.append([1])
        elif(labelInstance == "buzz"):
            # Buzz
            processedLabel.append([2])
        else:
            # Other
            processedLabel.append([0])

    return np_utils.to_categorical(np.array(processedLabel),4)


# ## Model Definition

# In[112]:


from keras.models import Sequential
from keras.layers import Dense, Activation, Dropout
from keras.callbacks import EarlyStopping, TensorBoard

import numpy as np

input_size = 10
drop_out = 0.1 #dropout
first_dense_layer_nodes  = 2048 #layers
second_dense_layer_nodes = 4

def get_model():
    
    # Why do we need a model?
    
    '''The term ML model refers to the model artifact that is created by the training process. 
    The training data must contain the correct answer, which is known as a target or target attribute. 
    The learning algorithm finds patterns in the training data that map the input data attributes to the target (the answer that you want to predict), and it outputs an ML model that captures these patterns. 
    You can use the ML model to get predictions on new data for which you do not know the target.
'''
    # Why use Dense layer and then activation?
    
    '''Dense Layer : A Dense layer is a Classic Neural Network Layer where each neuron receives input from all the neurons in the previous layer. 
    It is used between input and output layer to get the desired output. 
    one neuron is connected to another neuron in the other layer.
    
    Activation layer :  They basically decide whether a neuron should be activated or not. 
    Whether the information that the neuron is receiving is relevant for the given information or should it be ignored.
    The activation function is the non linear transformation that we do over the input signal. 
    This transformed output is then sent to the next layer of neurons as input.


'''
    # Why use sequential model with layers?
    
    '''Sequential layers allows us to create model layer by layer. 
    We create hidden layers with weights for the given input to get the desired output. 
    Whereas Non-sequential is a complex network such as siamese and residual networks.
'''
    model = Sequential()
    
    model.add(Dense(first_dense_layer_nodes, input_dim=input_size))

    model.add(Activation('relu')) # first Activation
    
    # Why dropout?
    '''
    Dropout is a regularization technique. 
    It aims to reduce the complexity of the model with a goal of preventing overfitting. 
    '''
    model.add(Dropout(drop_out))
    
    model.add(Dense(second_dense_layer_nodes))
    
    model.add(Activation('softmax')) # Second Activation
    
    # Why Softmax?
    
    '''If we use softmax layer as output layer. 
    Exponential function will increase the probability of maximum value of the previous layer compared to other value. 
    The softmax function squashes the outputs of each unit to be between 0 and 1, just like a sigmoid function. 
    But it also divides each output such that the total sum of the outputs is equal to 1. 
    Also, summation of all output will be equal to 1.0 always.
'''
    model.summary()
    
    # Why use categorical_crossentropy?
    
    '''Categorical crossentropy is a loss function. 
    It is one of the three parameters that we use to compile a model. 
    As we have binary vectors as our data. So we use Categorical Crossentropy. 
    Here each integer value is represented as a binary vector that is all zeros except the index of the number.
'''
    
    # optimizer
    model.compile(optimizer='rmsprop',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
    
    return model


# # <font color='blue'>Creating Training and Testing Datafiles</font>

# In[113]:


# Create datafiles
createInputCSV(101,1001,'training.csv')
createInputCSV(1,101,'testing.csv')


# # <font color='blue'>Creating Model</font>

# In[114]:


model = get_model()


# # <font color = blue>Run Model</font>

# In[115]:


validation_data_split = 0.2
num_epochs = 10000
model_batch_size = 128
tb_batch_size = 32
early_patience = 100

tensorboard_cb   = TensorBoard(log_dir='logs', batch_size= tb_batch_size, write_graph= True)
earlystopping_cb = EarlyStopping(monitor='val_loss', verbose=1, patience=early_patience, mode='min')

# Read Dataset
dataset = pd.read_csv('training.csv')

# Process Dataset
processedData, processedLabel = processData(dataset)
history = model.fit(processedData
                    , processedLabel
                    , validation_split=validation_data_split
                    , epochs=num_epochs
                    , batch_size=model_batch_size
                    , callbacks = [tensorboard_cb,earlystopping_cb]
                   )


# # <font color = blue>Training and Validation Graphs</font>

# In[116]:


get_ipython().run_line_magic('matplotlib', 'inline')
df = pd.DataFrame(history.history)
df.plot(subplots=True, grid=True, figsize=(10,15))


# # <font color = blue>Testing Accuracy [Software 2.0]</font>

# In[117]:


def decodeLabel(encodedLabel):
    if encodedLabel == 0:
        return "other"
    elif encodedLabel == 1:
        return "fizz"
    elif encodedLabel == 2:
        return "buzz"
    elif encodedLabel == 3:
        return "fizzbuzz"


# In[118]:


wrong   = 0
right   = 0

testData = pd.read_csv('testing.csv')

processedTestData  = encodeData(testData['input'].values)
processedTestLabel = encodeLabel(testData['label'].values)
predictedTestLabel = []

for i,j in zip(processedTestData,processedTestLabel):
    y = model.predict(np.array(i).reshape(-1,10))
    predictedTestLabel.append(decodeLabel(y.argmax()))

    if j.argmax() == y.argmax():
        right = right + 1
    else:
        wrong = wrong + 1

print("Errors: " + str(wrong), " Correct :" + str(right))

print("Testing Accuracy: " + str(right/(right+wrong)*100))

testDataInput = testData['input'].tolist()
testDataLabel = testData['label'].tolist()

testDataInput.insert(0, "UBID")
testDataLabel.insert(0, "asishkak")

testDataInput.insert(1, "personNumber")
testDataLabel.insert(1, "50288695")

predictedTestLabel.insert(0,"")
predictedTestLabel.insert(1,"")

output = {}
output["input"] = testDataInput
output["label"] = testDataLabel
output["predicted_label"] = predictedTestLabel

opdf = pd.DataFrame(output)
opdf.to_csv('output.csv')

